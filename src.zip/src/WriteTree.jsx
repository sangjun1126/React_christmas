import React from 'react'

const WriteTree = () => {
  return (
    <div>
      <h2> 연동 성공! </h2>
    </div>
  )
}

export default WriteTree